print('sad')

